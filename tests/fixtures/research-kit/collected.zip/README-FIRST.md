# COLLECTED CORPUS — REVIEW REQUIRED

Research-Kit collected evidence successfully.

This package is **not an approved research brief** and does not authorize
an AI or person to begin building.

The commands below are written for PowerShell, bash and zsh. In cmd.exe, write
`%USERPROFILE%` where a command says `$HOME`.

## Three required review steps

The agent does them, and declares it in the brief with the line `Reviewed by: agent`;
the manifest carries it as `review.by`.

1. Review and classify every row in `project/research/MAP.md`.
2. Review every finding in `project/research/EVIDENCE.md`.
3. From the `project` folder, run preflight until it prints PASS, then draft the
   brief and answer its two **TODO** sections in `project/research/BRIEF.md`:

```
node "$HOME/.agents/research-kit/bin/preflight.mjs"
node "$HOME/.agents/research-kit/bin/brief.mjs"
```

## Then package the reviewed project

From this folder, the one holding this file:

```
node "$HOME/.agents/research-kit/bin/artifact.mjs" create --root project --output reviewed.zip --repository moonaliza-fixtures/synthetic --ref fixture --commit 5588ce3def50e7e3702e5f84251bfd3d445f3df0 --workflow fixture-generation --run-id 1 --run-attempt 1 --client-ref moonaliza-fixture
```

It writes `reviewed.zip` with the identity of this package and a manifest derived from
the project as it now stands. Building is permitted only when that manifest says all of:

- `manifest.json` contains `"state": "APPROVED_BRIEF"`
- `manifest.json` contains `"buildAuthorized": true`
- `manifest.json` contains `"gate": { "verdict": "PASS" }`

Start by opening:

`project/START_HERE.md`
