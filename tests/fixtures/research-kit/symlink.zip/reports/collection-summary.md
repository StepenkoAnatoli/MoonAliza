# Collection summary

Package `FP-032851AC4D9F4F801BAF2EF467`, written 2026-10-24T20:06:57.334Z.

| | |
|---|---|
| state | `APPROVED_BRIEF` |
| build authorized | `true` |
| gate verdict | `PASS` |
| captures | 1 |
| credits used | not recorded |
| fetch provider | firecrawl-cli |
| completeness | FULL |

**Gate warnings from this evaluation: 1.**

These findings apply to the whole corpus at the time of this evaluation. Re-run
preflight after edits; this list is not a fresh evaluation of the resulting document.

- **corroboration/single-source** (U-1): U-1 rests on E-01 alone - one reading, so a correct source and a lucky one look the same

## Review state

- map classified: **true**
- findings reviewed: **true**
- brief reviewed: **true**
- reviewed by: **agent** (the reviewer's declaration in BRIEF.md; not verified)

## What this file is not

A summary is not a verdict. `manifest.json` is the machine-readable contract, and a
consumer that disagrees with this page should believe the manifest.
