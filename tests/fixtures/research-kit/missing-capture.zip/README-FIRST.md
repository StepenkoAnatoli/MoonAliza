# APPROVED RESEARCH — BUILDING IS AUTHORIZED

Research-Kit collected this evidence, it was reviewed by an agent (as declared in the brief), and the
gate passed.

`manifest.json` carries `"state": "APPROVED_BRIEF"`, `"buildAuthorized": true` and
`"gate": { "verdict": "PASS" }`. Confirm all three before acting on this package —
this file is prose and the manifest is the contract.

Start by opening:

`project/research/BRIEF.md`
