# Evidence

| ID | Retrieved | Type | URL | Finding | Raw |
|---|---|---|---|---|---|
| E-01 | 2026-09-30 | P | https://example.invalid/docs/limits | The free tier caps this design at 10 requests per minute, which is what sets the collector default; the 1,000 included credits are roughly 25 runs at the quick depth. | research/raw/2026-09-30-limits-example-a4e22bcd.md |
