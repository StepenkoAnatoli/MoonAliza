# MAP - topic decomposition

## Topic

Fixture topic

## Subtopics

| ID | Subtopic | Why it matters | Status | Covered by |
|---|---|---|---|---|
| D-1 | Access model | Decides the collection design | COVERED | U-1 |
| D-2 | Auth and credentials | Who holds the key | COVERED | U-1 |
| D-3 | Rate limits and quotas | Caps every cadence | COVERED | U-1 |
| D-4 | ToS, licensing, legality of the intended use | A prohibition ends the design | DISMISSED | public docs, personal research, no redistribution |
| D-5 | Data schema and its stability | Shape drift | DISMISSED | captures are frozen point-in-time; there is no extraction layer |
| D-6 | Freshness and staleness | What staleness costs | DISMISSED | handled structurally by retrieval dates and --refresh-days |
| D-7 | Cost at expected volume | Decides viability | COVERED | U-1 |
| D-8 | Runtime and platform limits | Where this executes | DISMISSED | one runtime, one machine, fixed by the fixture |
| D-9 | Output obtainability | Load-bearing | COVERED | U-1 |
