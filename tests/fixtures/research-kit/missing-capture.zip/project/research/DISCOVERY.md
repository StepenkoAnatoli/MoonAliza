# Discovery Contract - Fixture topic

## Build intent

A fixture project that passes its own gate, so a test can prove the gate says PASS for a
corpus that deserves it.

## Unknowns

| ID | Unknown | Why it blocks the build | Status | Evidence |
|---|---|---|---|---|
| U-1 | What does the free tier allow? | Sets the collector's budget | CLOSED | E-01: 10 requests per minute, 1,000 credits |
