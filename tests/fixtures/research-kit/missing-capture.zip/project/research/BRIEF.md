# Brief - Fixture topic

_Auto-drafted 2026-09-30 by `bin/brief.mjs` from the corpus. Sections marked **TODO**
require the reviewing agent's judgement; everything else is assembled from evidence already
in `research/`. While a **TODO** remains, this brief is **not reviewed** and the
handoff is **not approved** - a structurally valid corpus, a reviewed one, and an
approved handoff are three different states._

Reviewed by: _agent - the agent that classified the map, rewrote the findings and answered the **TODO** sections replaces this line with `Reviewed by: agent`_

**This is the phase-1 to phase-2 handoff.** **Gate state: not evaluated in this run.**

Whoever you are - another agent, a different model, or a person - read this file
first. You should not need to re-research anything to start work. If something
here is not enough to build from, say which fact is missing rather than guessing
it: that is a phase-1 gap to close, not a phase-2 judgment call.

## Intent

A fixture project that passes its own gate, so a test can prove the gate says PASS for a
corpus that deserves it.

## What we verified

| Claim | Source | Type |
|---|---|---|
| The free tier caps this design at 10 requests per minute, which is what sets the collector default; the 1,000 included credits are roughly 25 runs at the quick depth. | E-01 `example.invalid` (U-1) | P |

## Contradictions and how they were resolved

None. One source, re-read on 2026-09-30, and nothing else in the corpus speaks to the same limit.

## Known unknowns

None. Every blocking unknown was closed with cited evidence.

## Decision

Build against a 10-request-per-minute ceiling and a 1,000-credit month. Out of scope: paid tiers, which no row in this corpus touches.

## Next steps

1. Review the **TODO** sections above (Contradictions, Decision) before handing off.
2. Hand this file to the builder (phase 2). Re-running `node "C:\Users\PC\Desktop\CODEX PROJECT FOLDER\2026-09-24\files-mentioned-by-the-user-rework\MoonAliza\.build\rk-generation-oq1R0m\current\research-kit/bin/brief.mjs"`
   redrafts this file while it is unedited; after any edit it refuses without `--force`,
   so your judgements are preserved.

<!-- research-kit:brief-draft body=cf798c46322c30c8 inputs=5ebcce47415eab80 gate=unknown -->

Reviewed by: agent
