# COLLECTION STOPPED

Research-Kit did not finish collecting. This package is here so the failure can be
diagnosed; it holds no usable corpus and authorizes nothing.

First blocking finding: contract-missing — research/DISCOVERY.md is missing. A gated project without its contract fails harder, not open.

See `reports/problems.json` for the full list.
