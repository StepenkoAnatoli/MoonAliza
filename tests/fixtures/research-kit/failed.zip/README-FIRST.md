# COLLECTION STOPPED

Fetchproof did not finish collecting. This package is here so the failure can be
diagnosed; it holds no usable corpus and authorizes nothing.

**Gate warnings from this evaluation: 1.**

These findings apply to the whole corpus at the time of this evaluation. Re-run
preflight after edits; this list is not a fresh evaluation of the resulting document.

- **subtopic-coverage/no-coverage-claim**: no coverage claim: research/MAP.md has no subtopic rows, so the gate cannot tell a thorough contract from a shallow one

First blocking finding: contract-missing — research/DISCOVERY.md is missing or could not be read. A gated project without its contract fails harder, not open.

See `reports/problems.json` for the full list.
