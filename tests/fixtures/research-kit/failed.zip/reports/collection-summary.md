# Collection summary

Package `FP-7B9CD9304C5E06A646EC7125C1`, written 2026-10-24T20:07:08.707Z.

| | |
|---|---|
| state | `COLLECTION_FAILED` |
| build authorized | `false` |
| gate verdict | `FAIL` |
| captures | 0 |
| credits used | not recorded |
| fetch provider | none |
| completeness | NONE |

**Gate warnings from this evaluation: 1.**

These findings apply to the whole corpus at the time of this evaluation. Re-run
preflight after edits; this list is not a fresh evaluation of the resulting document.

- **subtopic-coverage/no-coverage-claim**: no coverage claim: research/MAP.md has no subtopic rows, so the gate cannot tell a thorough contract from a shallow one

## Review state

- map classified: **false**
- findings reviewed: **false**
- brief reviewed: **false**
- reviewed by: **undeclared** (the reviewer's declaration in BRIEF.md; not verified)

## Blocking findings

- `contract-missing` — research/DISCOVERY.md is missing or could not be read. A gated project without its contract fails harder, not open.
- `ledger-missing` — research/raw/.fetches.jsonl is absent - evidence must be fetched, not typed, and the ledger is what proves it
- `raw-missing` — research/raw/ does not exist - a gated project needs somewhere to keep its captures

## What this file is not

A summary is not a verdict. `manifest.json` is the machine-readable contract, and a
consumer that disagrees with this page should believe the manifest.
