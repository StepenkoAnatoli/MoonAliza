# Collection summary

Package `RK-AC95F793C166EBB7C47A2644F8`, written 2026-10-24T20:07:13.484Z.

| | |
|---|---|
| state | `HUMAN_REVIEW_REQUIRED` |
| build authorized | `false` |
| gate verdict | `FAIL` |
| captures | 1 |
| credits used | not recorded |
| fetch provider | firecrawl-cli |
| completeness | FULL |

## Review state

- map classified: **false**
- findings reviewed: **false** — still carrying the extractor's own words: E-01
- brief reviewed: **false**
- reviewed by: **undeclared** (the reviewer's declaration in BRIEF.md; not verified)

## Blocking findings

- `status` — D-1 has status "UNREVIEWED" - must be COVERED, DISMISSED, or GAP
- `status` — D-2 has status "UNREVIEWED" - must be COVERED, DISMISSED, or GAP
- `status` — D-3 has status "UNREVIEWED" - must be COVERED, DISMISSED, or GAP
- `status` — D-7 has status "UNREVIEWED" - must be COVERED, DISMISSED, or GAP
- `status` — D-9 has status "UNREVIEWED" - must be COVERED, DISMISSED, or GAP

## What this file is not

A summary is not a verdict. `manifest.json` is the machine-readable contract, and a
consumer that disagrees with this page should believe the manifest.
