# Evidence

| ID | Retrieved | Type | URL | Finding | Raw |
|---|---|---|---|---|---|
| E-01 | 2026-09-30 | P | https://example.invalid/docs/limits | The free plan allows 10 requests per minute and includes 1,000 credits. | research/raw/2026-09-30-limits-example-a4e22bcd.md |
