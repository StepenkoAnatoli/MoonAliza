<!-- research-kit:brief=scaffold -->
# Brief - Fixture topic

This is the scaffold, not a brief. `node "C:\Users\PC\Desktop\CODEX PROJECT FOLDER\2026-09-24\files-mentioned-by-the-user-rework\MoonAliza\.build\rk-generation-oq1R0m\legacy\research-kit/bin/brief.mjs"` drafts the real one from
the corpus once the gate passes; the marker on the first line is what tells the drafter
that nothing here is anybody's judgement yet.

**This is the phase-1 to phase-2 handoff** - the only file phase 2 is required to read.
Writing it is part of phase 1 and is not optional: a passing gate with no handoff means
the next agent re-researches everything you just verified.

## Intent

## What we verified

## Contradictions and how they were resolved

## Known unknowns

## Decision

## Next steps
